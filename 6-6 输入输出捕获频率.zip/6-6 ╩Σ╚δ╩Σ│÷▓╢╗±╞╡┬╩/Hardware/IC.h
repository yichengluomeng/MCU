#ifndef __PWM_H
#define __PWM_H

void IC_Init();
uint32_t IC_GetFreq(void);

#endif


