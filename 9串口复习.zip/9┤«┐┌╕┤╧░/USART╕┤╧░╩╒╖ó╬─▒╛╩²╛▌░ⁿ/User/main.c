#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"

int main(void)
{
	uint16_t Rx_Num;
	uint16_t Array[]={0x41,0x42,0x44,0x45};
	OLED_Init();
	Serial_Init();
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
//	GPIO_ResetBits(GPIOA, GPIO_Pin_1);
	GPIO_SetBits(GPIOA, GPIO_Pin_1);	
	
//	Serial_TxPacket[0] = 0x01;
//	Serial_TxPacket[1] = 0x02;
//	Serial_TxPacket[2] = 0x03;
//	Serial_TxPacket[3] = 0x04;
	
//	Serial_SendPacket();
	
	while (1)
	{
		if (SerialRx_Flag == 1)
		{
			OLED_ShowString(1,1,"                ");
			OLED_ShowString(1,1,Serial_RxPacket);
			Serial_SendString("LED_ON_OK\r\n");
			SerialRx_Flag = 0;
		}	
	}
}
