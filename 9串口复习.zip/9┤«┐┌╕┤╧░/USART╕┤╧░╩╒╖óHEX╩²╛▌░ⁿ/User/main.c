#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"

int main(void)
{
	uint16_t Rx_Num;
	uint16_t Array[]={0x41,0x42,0x44,0x45};
	OLED_Init();
	Serial_Init();
	Serial_SendByte(0x41);
//	Serial_SendString("\r\n");
//	Serial_SendArray(Array,4);
//	Serial_SendString("\r\n");
//	Serial_SendString("Hello World!\r\n");
//	Serial_SendNumber(1324,4);
//	Serial_SendString("\r\n");
	
//	Serial_TxPacket[0] = 0x01;
//	Serial_TxPacket[1] = 0x02;
//	Serial_TxPacket[2] = 0x03;
//	Serial_TxPacket[3] = 0x04;
	
//	Serial_SendPacket();
	
	while (1)
	{
		if (Get_SerialRx_Flag()==1)
		{
//			OLED_ShowHexNum(1,1,Serial_RxPacket[0],2);
//			OLED_ShowHexNum(1,4,Serial_RxPacket[1],2);
//			OLED_ShowHexNum(1,7,Serial_RxPacket[2],2);
//			OLED_ShowHexNum(1,10,Serial_RxPacket[3],2);
			
		}
//		if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==SET)
//		{
//			Rx_Num=USART_ReceiveData(USART1);
//			OLED_ShowHexNum(1,1,Rx_Num,4);
//		}
//		
//		if(Get_SerialRx_Flag()==SET)
//		{
//			Rx_Num=Get_SerialRx_Data();
//			OLED_ShowHexNum(1,1,Rx_Num,4);
//		}
		
	}
}
