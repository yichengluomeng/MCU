#ifndef __TIM2ER_H
#define __TIM2ER_H

void TIM2_Init(uint32_t MemoryBaseAddr);
void TIM2_Cmd(FunctionalState NewState);
void TIM2_SetCompare1(uint16_t Value);

void DMA1_Init(uint32_t MemoryBaseAddr);
void DMA1_SetIRQHandler(void (*IRQHandler)(void));
void DMA1_Start(uint16_t DataNumber);

#endif