#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>
#include "string.h"
#include "LED.h"
#include "OLED.h"

char Bluetooth_RxPacket[100];		//定义接收数据包数组，数据包格式"@MSG\r\n"
uint8_t Bluetooth_RxData;		//定义串口接收的数据变量
uint8_t Bluetooth_RxFlag;	
uint8_t Bluetooth_ReadDataNum;

void Bluetooth_ReadData();

void Bluetooth_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//TX输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//RX输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;//波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//不使用流控
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//工作在发送与接收模式
	USART_InitStructure.USART_Parity = USART_Parity_No;//奇偶校验
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一位停止位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//八位数据位
	USART_Init(USART1,&USART_InitStructure);
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_StructureInit;
	NVIC_StructureInit.NVIC_IRQChannel = USART1_IRQn;
	NVIC_StructureInit.NVIC_IRQChannelCmd = ENABLE;
	NVIC_StructureInit.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_StructureInit.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_StructureInit);
	
	USART_Cmd(USART1,ENABLE);
	
}
/*
蓝牙发送一个字节的函数
形参
Byte：发送的字节
*/
void Bluetooth_SendByte(uint8_t Byte)
{
	USART_SendData(USART1,Byte);//发送函数
	while (USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);//检查TDR是否为空
}

/*
蓝牙发送一个数组的函数
形参
*Array：数组的地址
Length：该数组有多少个参数
*/
void Bluetooth_SendArray(uint8_t *Array , uint8_t Length)
{
	uint8_t i;
	for (i=0;i<Length;i++)//循环调用发送字节函数，将数组中的数据依次发送
	{
		Bluetooth_SendByte(Array[i]);
	}
}

/*
蓝牙发送字符串的函数
形参
*String：发送字符串的地址
*/
void Bluetooth_SendString(char *String)
{
	uint8_t i;
	for(i=0;String[i]!='\0' ;i++)//循环调用发送字节函数，将字符串中的数据依次发送
	{
		Bluetooth_SendByte(String[i]);
	}
}
/*
取次方的函数
返回X的Y次方
*/
uint32_t Bluetooth_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;	
	while (Y --)			
	{
		Result *= X;//	
	}
	return Result;
}

/*
蓝牙发送数字的函数
形参
Num：发送的数字
Length：发送数字的个数

实现思路：
以Num为12345为例
Length=5	
取次方函数 Serial_Pow(10, Length - i - 1)=10^4=10000		Length - i - 1=4
12345/10000=1		1%10=1

Length=4	
取次方函数 Serial_Pow(10, Length - i - 1)=10^3=1000		Length - i - 1=3
12345/1000=12		12%10=2
……………………
加上'0'，在ASCLL码中进行位移0位……
*/
void Bluetooth_SendNum(uint32_t Num, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i ++)		
	{
		Bluetooth_SendByte(Num / Bluetooth_Pow(10, Length - i - 1) % 10 + '0');	
	}
}

/*
函    数：使用printf需要重定向的底层函数
参    数：保持原始格式即可，无需变动
返 回 值：保持原始格式即可，无需变动
复制于江科大移植函数
*/
int fputc(int ch, FILE *f)
{
	Bluetooth_SendByte(ch);			//将printf的底层重定向到自己的发送字节函数
	return ch;
}

/*
函    数：自己封装的prinf函数
参    数：format 格式化字符串
参    数：... 可变的参数列表
返 回 值：无
复制于江科大移植函数
*/
void Bluetooth_Printf(char *format, ...)
{
	char String[100];				//定义字符数组
	va_list arg;					//定义可变参数列表数据类型的变量arg
	va_start(arg, format);			//从format开始，接收参数列表到arg变量
	vsprintf(String, format, arg);	//使用vsprintf打印格式化字符串和参数列表到字符数组中
	va_end(arg);					//结束变量arg
	Bluetooth_SendString(String);		//串口发送字符数组（字符串）
}

/*
查询接收标志位
标志位读取后自动清零
*/
uint8_t Bluetooth_GetRxFlag(void)
{
	if (Bluetooth_RxFlag == 1)			//如果标志位为1
	{
		Bluetooth_RxFlag = 0;
		return 1;					//则返回1，并自动清零标志位
	}
	return 0;						//如果标志位为0，则返回0
}

/*
蓝牙获取串口接收数据的函数
形参
*/
uint8_t Bluetooth_GetRxData(void)
{
	return Bluetooth_RxData;			//返回接收的数据变量
}

/*
蓝牙发送文本数据包的函数
形参
*String：要发送的字符串
*/
void Bluetooth_Sendtext(char *String)
{
	Bluetooth_SendString("@");//发送包头
	uint8_t i;
	for(i=0;String[i]!='\0' ;i++)//循环调用发送字节函数，将字符串中的数据依次发送
	{
		Bluetooth_SendByte(String[i]);
	}
	Bluetooth_SendString("\r");//发送包尾
	Bluetooth_SendString("\n");//发送包尾
}
/*
蓝牙发送文本包比较的函数
可以设置一个形参char用以比较函数
1，发送Close，开始关闭灯
2，发送White，开始点亮白灯
3，发送colored，开始点亮变换的彩灯
4，发送lamp，开启WS2812
*/
uint8_t Key_GetKeyNumber(void)
{
	Bluetooth_ReadData();
	uint8_t Temp;
	Temp=Bluetooth_ReadDataNum;
	Bluetooth_ReadDataNum=0;

	return Temp;
}

/*
为主函数的模式返回一个值
*/
void Bluetooth_ReadData()
{
	static uint8_t pRxPacket = 0;
	static uint8_t Bluetooth_ReadDataNum_Last,Bluetooth_ReadDataNum_Now;
	Bluetooth_ReadDataNum_Last=Bluetooth_ReadDataNum_Now;
	Bluetooth_ReadDataNum_Now=0;
	if (strcmp(Bluetooth_RxPacket, "Close") == 0)			//Close
		{
			Bluetooth_SendString("Close_OK\r\n");				//串口回传一个字符串Breathing_lamps_OK
//			OLED_ShowString(1,1,"            ");
//			OLED_ShowString(1,1,"Close_OK");
			Bluetooth_ReadDataNum_Now = 1;
		}
	if (strcmp(Bluetooth_RxPacket, "White") == 0)	//White
		{
			Bluetooth_SendString("White_OK\r\n");			//串口回传一个字符串Running_water_lamps_OK
//			OLED_ShowString(1,1,"            ");
//			OLED_ShowString(1,1,"White_OK");
			Bluetooth_ReadDataNum_Now = 2;
		}
	if (strcmp(Bluetooth_RxPacket, "colored") == 0)	//colored
		{
			Bluetooth_SendString("colored_OK\r\n");			//串口回传一个字符串Running_water_lamps_OK
//			OLED_ShowString(1,1,"            ");
//			OLED_ShowString(1,1,"colored_OK");
			Bluetooth_ReadDataNum_Now = 3;
		}
	if (strcmp(Bluetooth_RxPacket, "Lamp") == 0)	//如果收到Lamp指令
		{
			Bluetooth_SendString("Lamp_OK\r\n");			//串口回传一个字符串Lamp_OK
				
			if (GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_3) == 0)
			{
				GPIO_SetBits(GPIOA, GPIO_Pin_3);
			}
			else
			{
				GPIO_ResetBits(GPIOA, GPIO_Pin_3);
			}
		}
	if(Bluetooth_ReadDataNum_Last==1 && Bluetooth_ReadDataNum_Now==0)
	{
		Bluetooth_ReadDataNum=1;
	}
	if(Bluetooth_ReadDataNum_Last==2 && Bluetooth_ReadDataNum_Now==0)
	{
		Bluetooth_ReadDataNum=2;
	}
	if(Bluetooth_ReadDataNum_Last==3 && Bluetooth_ReadDataNum_Now==0)
	{
		Bluetooth_ReadDataNum=3;
	}
	Bluetooth_RxPacket[0]=0;
}
	

/*
USART1中断函数
注意事项：此函数为中断函数，无需调用，中断触发后自动执行
函数名为预留的指定名称，可以从启动文件复制
请确保函数名正确，不能有任何差异，否则中断函数将不能进入

接受文本数据包，不固定数据长度的

*/
void USART1_IRQHandler(void)
{
	static uint8_t RxState = 0;		//定义表示当前状态机状态的静态变量
	static uint8_t pRxPacket = 0;	//定义表示当前接收数据位置的静态变量
	
	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)		//判断是否是USART1的接收事件触发的中断
	{
		uint8_t RxData = USART_ReceiveData(USART1);
		
		if (RxState==0)
		{
			if (RxData=='@')
			{
				RxState=1;
				pRxPacket = 0;
			}				
		}
		else if (RxState==1)
		{
			if (RxData=='\r')
			{
				RxState=2;
			}
			else 
			{
				Bluetooth_RxPacket[pRxPacket]=RxData;
				pRxPacket++;
			}
			
		}
		else if (RxState==2)
		{
			if (RxData=='\n')
			{
				RxState=0;
				Bluetooth_RxPacket[pRxPacket]='\0';
				Bluetooth_RxFlag=1;
			}
		}
//		Bluetooth_ReadData();
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);			//清除USART1的RXNE标志位
																//读取数据寄存器会自动清除此标志位
																//如果已经读取了数据寄存器，也可以不执行此代码
	}
}
