#include "stm32f10x.h"
#include "OLED.h"

uint8_t Key_KeyNumber;

void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef  GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin= GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode= GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

uint8_t Key_GetKeyNumber(void)
{
	uint8_t Temp;
	Temp=Key_KeyNumber;
	Key_KeyNumber=0;
	return Temp;
}

void Key_Loop(void)
{
	static uint8_t KeyLast,KeyNow;
	KeyLast=KeyNow;
	KeyNow=0;
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)==1)
	{
		KeyNow=1;
	}
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)==1)
	{
		KeyNow=2;
		
	}
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2)==1)
	{
		KeyNow=3;
	}
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3)==1)
	{
		KeyNow=4;
	}
	if(KeyLast==1 && KeyNow==0)
	{
		Key_KeyNumber=1;
	}
	if(KeyLast==2 && KeyNow==0)
	{
		Key_KeyNumber=2;
	}
	if(KeyLast==3 && KeyNow==0)
	{
		Key_KeyNumber=3;
	}
	if(KeyLast==4 && KeyNow==0)
	{
		Key_KeyNumber=4;
	}
}
