#include "stm32f10x.h"                  // Device header
#include "MySPI.h"
#include "Delay.h"
#include "RC522_Ins.h"
#include "OLED.h"

extern uint8_t UID[4],Temp[4];
extern uint8_t UI0[4];							
extern uint8_t UI1[4];							
extern uint8_t UI2[4];							
extern uint8_t UI3[4];
extern uint8_t UI4[4];							
extern uint8_t UI5[4];							
extern uint8_t UI6[4];							
extern uint8_t UI7[4];

//初始化
void RC522_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	MySPI_Init();
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;//REST
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}	

/*
	RC522模块读取数据时地址最高位为1，最低位为0
	例如
	//0x7E						//0111 1110
	//Address = Status2Reg   	//0000 1000
	//Address<<1   				//0001 0000
	//(Address<<1)&0x7E		    //0001 0000
    //((Address<<1)&0x7E)|0x80	//1001 0000
	*/
/*
函数功能：读取指定地址的一个字节的数据
函数参数：Address 指定的地址
返回值  ：读取的数据
*/
uint8_t RC522_Read_Data(uint8_t Address)
{
	uint8_t ReadByte = 0x00;//接收的数据
	uint8_t Temp_Add;//临时地址数据
	
	Temp_Add=((Address<<1)&0x7E)|0x80;//读取地址
	
	MySPI_W_SCK(0);//数据在下降沿变化
	
	MySPI_Start();//起始条件
	
	MySPI_WriteByte(Temp_Add);//发送地址
	
	ReadByte = MySPI_ReadByte();//读取地址
	
	MySPI_Stop();//结束条件
	
	return ReadByte;//返回读取的值
}

/*
函数功能：在指定地址写入一个字节的数据
函数参数：Address 指定的地址
		  Value   写入的数据
返回值  ：无返回值
*/
void RC522_Write_Data(uint8_t Address,uint8_t Value)
{
	uint8_t Temp_Add;//临时地址数据
	
	Temp_Add=((Address<<1)&0x7E);//读取地址
	
	MySPI_W_SCK(0);//数据在下降沿变化
	
	MySPI_Start();//起始条件
	
	MySPI_WriteByte(Temp_Add);//发送地址
	
	MySPI_WriteByte(Value);//读取地址
	
	MySPI_Stop();//结束条件
}
/*
函数功能：复位RC522
函数参数：无参数
返回值  ：MI_OK
*/
uint8_t RC522_Reset()
{
	MySPI_W_RESET(1);
	Delay_ms(1);	
	MySPI_W_RESET(0);
	Delay_ms(1);		
	MySPI_W_RESET(1);     	
	Delay_ms(1);
	RC522_Write_Data(CommandReg,PCD_RESETPHASE); //soft reset
	while(RC522_Read_Data(CommandReg) & 0x10);
	Delay_ms(1);
	
	RC522_Write_Data(ModeReg,0x3D);            //
    RC522_Write_Data(TReloadRegL,30);           
    RC522_Write_Data(TReloadRegH,0);
    RC522_Write_Data(TModeReg,0x8D);
    RC522_Write_Data(TPrescalerReg,0x3E);
    RC522_Write_Data(TxAutoReg,0x40);
	
	return MI_OK;
}

/*
函数功能：置位RC522
函数参数：reg 寄存器地址
		  mask 置位值
返回值  ：无
*/
void RC522_Set_Bit_Mask(uint8_t reg,uint8_t mask)
{
	int8_t tmp = 0x0;
    tmp = RC522_Read_Data(reg);
    RC522_Write_Data(reg,tmp | mask);  // set bit mask
}

/*
函数功能：清除置位RC522
函数参数：reg 寄存器地址
		  mask 置位值
返回值  ：无
*/
void RC522_Clear_Bit_Mask(uint8_t reg,uint8_t mask)
{
	int8_t tmp = 0x0;
    tmp = RC522_Read_Data(reg);
    RC522_Write_Data(reg, tmp & ~mask);  // set bit mask
}

/*
函数功能：开启天线
函数参数：无
返回值  ：无
*/
void RC522_Antenna_Open()
{
    uint8_t i;
    i = RC522_Read_Data(TxControlReg);
    if (!(i & 0x03))
    {
        RC522_Set_Bit_Mask(TxControlReg, 0x03);
    }
}


/*
函数功能：关闭天线
函数参数：无
返回值  ：无
*/
void RC522_Antenna_Close()
{
    RC522_Clear_Bit_Mask(TxControlReg, 0x03);
}

/*
函数功能：通讯函数
		  通过与RC522芯片与ISO14443A进行通讯
函数参数：Command RC522命令字
		  *pInData 发送到卡片的数据
		  InLenByte 发送数据的字节长度
		  *pOutData 接收到的卡片返回的数据
		  *pOutLenBit 返回数据的长度
返回值  ：无
*/
int8_t RC522_ToCard( uint8_t Command, 
					   uint8_t *pInData, 
					   uint8_t InLenByte,
					   uint8_t *pOutData, 
					   uint32_t  *pOutLenBit )
{
	int8_t status = MI_ERR;
	uint8_t irqEn   = 0x00;
	uint8_t waitFor = 0x00;
	uint8_t lastBits;
	uint8_t n;
	uint32_t i;
	switch (Command)
    {
		case PCD_AUTHENT:
			irqEn   = 0x12;
			waitFor = 0x10;
			break;
		case PCD_TRANSCEIVE:
			irqEn   = 0x77;
			waitFor = 0x30;
			break;
		default:
			break;
    }
	RC522_Write_Data(ComIEnReg,irqEn|0x80);	
	RC522_Clear_Bit_Mask(ComIrqReg,0x80);	
	RC522_Write_Data(CommandReg,PCD_IDLE);  
	RC522_Set_Bit_Mask(FIFOLevelReg,0x80);	

	for (i=0; i<InLenByte; i++)
	{   
		RC522_Write_Data(FIFODataReg, pInData[i]);   
	}
	RC522_Write_Data(CommandReg, Command);   //

	if (Command == PCD_TRANSCEIVE)
	{    
		RC522_Set_Bit_Mask(BitFramingReg,0x80);  //
	}
	n = RC522_Read_Data(ComIrqReg);
	i = 1500;//
	do 
	{
		n = RC522_Read_Data(ComIrqReg);	
		i--;	
	}
	while ((i!=0) && !(n&0x01) && !(n&waitFor));
	RC522_Clear_Bit_Mask(BitFramingReg,0x80);	  
	if (i!=0)
	{    
		if(!(RC522_Read_Data(ErrorReg)&0x1B))
		{
			status = MI_OK;
			if (n & irqEn & 0x01)
			{
				status = MI_NOTAGERR;
			}
			if (Command == PCD_TRANSCEIVE)
			{
				n = RC522_Read_Data(FIFOLevelReg);
				lastBits = RC522_Read_Data(ControlReg) & 0x07;
				if (lastBits)
				{
					*pOutLenBit = (n-1)*8 + lastBits;
				}
				else
				{
					*pOutLenBit = n*8;
				}
				if (n == 0)
				{
					n = 1;
				}
				if (n > MAXRLEN)
				{	
					n = MAXRLEN;
				}
				for (i=0; i<n; i++)
				{
					pOutData[i] = RC522_Read_Data(FIFODataReg);
				}
			}
		}
		else
		{   
			status = MI_ERR;   
		}	
	}
	RC522_Set_Bit_Mask(ControlReg,0x80);           // stop timer now
	RC522_Write_Data(CommandReg,PCD_IDLE); 
	return status;
}

/*
函数功能：CRC校验函数
		  通过与RC522芯片对获取数据进行校验
函数参数：*pIndata 读取的CRCS数据
		  len 数据长度
		  *pOutData 计算的CRC结果
返回值  ：无
*/
void CalulateCRC(uint8_t *pIndata,uint8_t len,uint8_t *pOutData)
{
	uint8_t i,n;
	RC522_Clear_Bit_Mask(DivIrqReg,0x04);
	RC522_Write_Data(CommandReg,PCD_IDLE);
	RC522_Set_Bit_Mask(FIFOLevelReg,0x80);
	for (i=0; i<len; i++)
	{
		RC522_Write_Data(FIFODataReg, *(pIndata+i));
	}
	RC522_Write_Data(CommandReg, PCD_CALCCRC);
	i = 0xFF;
	do 
	{
		n = RC522_Read_Data(DivIrqReg);
		i--;
	}
	while ((i!=0) && !(n&0x04));
	pOutData[0] = RC522_Read_Data(CRCResultRegL);
	pOutData[1] = RC522_Read_Data(CRCResultRegM);
}

/*
函数功能：休眠
		  使卡片进入休眠状态
函数参数：	  
返回值  ：成功返回MI_OK
*/
int8_t MFRC522_Halt(void)
{
    
    uint32_t  unLen;
    uint8_t ucComMF522Buf[MAXRLEN]; 
	int8_t status;
    ucComMF522Buf[0] = PICC_HALT;
    ucComMF522Buf[1] = 0;
    CalulateCRC(ucComMF522Buf,2,&ucComMF522Buf[2]);
 
    status = RC522_ToCard(PCD_TRANSCEIVE,ucComMF522Buf,4,ucComMF522Buf,&unLen);

    return MI_OK;
}
/*
函数功能：寻卡函数
函数参数：req_code 寻卡方式
			 0x26；寻找未进入休眠状态的卡
		     0x52；寻找所有符合14443A标准的卡
		  *pTagType 卡片类型代码
			 0x4400；Mifare_UltraLight
			 0x0400；Mifare_One(S50)
			 0x0200；Mifare_One(S70)
			 0x0800；Mifare_Pro(X)
			 0x4403；Mifare_DESFire
返回值  ：成功返回MI_OK
*/
int8_t MFRC522_Request(uint8_t req_code,uint8_t *pTagType)
{
	int8_t status;  
	uint32_t  unLen;
	uint8_t ucComMF522Buf[MAXRLEN]; 

	RC522_Clear_Bit_Mask(Status2Reg,0x08);
	RC522_Write_Data(BitFramingReg,0x07);
	RC522_Set_Bit_Mask(TxControlReg,0x03);

	ucComMF522Buf[0] = req_code;

	status = RC522_ToCard(PCD_TRANSCEIVE,ucComMF522Buf,1,ucComMF522Buf,&unLen);
	if ((status == MI_OK) && (unLen == 0x10))
	{    
		*pTagType     = ucComMF522Buf[0];
		*(pTagType+1) = ucComMF522Buf[1];
	}
	else
	{   
		status = MI_ERR;  
	}
	return status;
}

/*
函数功能：防冲突函数
函数参数：*pSnr 卡片序列号4个字节
返回值  ：成功返回MI_OK
*/
char MFRC522_Anticoll(uint8_t *pSnr)
{
	int8_t status;
	uint8_t i,snr_check=0;
	uint32_t  unLen;
	uint8_t ucComMF522Buf[MAXRLEN]; 

	RC522_Clear_Bit_Mask(Status2Reg,0x08);
	RC522_Write_Data(BitFramingReg,0x00);
	RC522_Clear_Bit_Mask(CollReg,0x80);

	ucComMF522Buf[0] = PICC_ANTICOLL1;
	ucComMF522Buf[1] = 0x20;

	status = RC522_ToCard(PCD_TRANSCEIVE,ucComMF522Buf,2,ucComMF522Buf,&unLen);

	if (status == MI_OK)
	{
		for (i=0; i<4; i++)
		{   
			*(pSnr+i)  = ucComMF522Buf[i];
			snr_check ^= ucComMF522Buf[i];
		}
		if (snr_check != ucComMF522Buf[i])
		{
			status = MI_ERR;
		}
	}

	RC522_Set_Bit_Mask(CollReg,0x80);
	return status;
}

/*
函数功能：选卡函数
函数参数：*pSnr 卡片序列号4个字节
返回值  ：成功返回MI_OK
*/
char MFRC522_SelectTag(uint8_t *pSnr)
{
	int8_t status;
	uint8_t i;
	uint32_t  unLen;
	uint8_t ucComMF522Buf[MAXRLEN]; 

	ucComMF522Buf[0] = PICC_ANTICOLL1;//命令字
	ucComMF522Buf[1] = 0x70;//命令字
	ucComMF522Buf[6] = 0;
	for (i=0; i<4; i++)//获取卡片ID
	{
		ucComMF522Buf[i+2] = *(pSnr+i);
		ucComMF522Buf[6]  ^= *(pSnr+i);
	}
	//CRC校验，对前7个字节进行校验，返回的值放置在第8个位置上
	CalulateCRC(ucComMF522Buf,7,&ucComMF522Buf[7]);

	RC522_Clear_Bit_Mask(Status2Reg,0x08);
	//与RC522通讯并下发命令，原7位数据以及CRC校验2位数据，共9位发送给卡片
	status = RC522_ToCard(PCD_TRANSCEIVE,ucComMF522Buf,9,ucComMF522Buf,&unLen);

	if ((status == MI_OK) && (unLen == 0x18))
	{
		status = MI_OK;
	}
	else
	{
		status = MI_ERR;
	}
	return status;
}

/*
函数功能：验证卡片密码函数
函数参数：auth_mode 密码验证模式
				0x60 验证A密钥
				0z61 验证B密钥
          addr 块地址
		  *pKey 密码
          *pSnr 卡片序列号4个字节
返回值  ：成功返回MI_OK
*/
char MFRC522_AuthState(uint8_t auth_mode,
					   uint8_t addr,
					   uint8_t *pKey,
					   uint8_t *pSnr)
{
	int8_t status;
	uint32_t  unLen;
	uint8_t i,ucComMF522Buf[MAXRLEN]; 

	ucComMF522Buf[0] = auth_mode;
	ucComMF522Buf[1] = addr;
	for (i=0; i<6; i++)
	{
		ucComMF522Buf[i+2] = *(pKey+i);
	}
	for (i=0; i<4; i++)
	{
		ucComMF522Buf[i+8] = *(pSnr+i);
	}
	status = RC522_ToCard(PCD_AUTHENT,ucComMF522Buf,12,ucComMF522Buf,&unLen);
	if ((status != MI_OK) || (!(RC522_Read_Data(Status2Reg) & 0x08)))
	{
		status = MI_ERR;
	}
	return status;
}

/*
函数功能：读卡函数
函数参数：addr 块地址
          *pData 读出的数据16字节
返回值  ：成功返回MI_OK
*/
char MFRC522_Read(uint8_t addr,uint8_t *pData)
{
	int8_t status;
	uint32_t  unLen;
	uint8_t i,ucComMF522Buf[MAXRLEN]; 

	ucComMF522Buf[0] = PICC_READ;
	ucComMF522Buf[1] = addr;
	CalulateCRC(ucComMF522Buf,2,&ucComMF522Buf[2]);

	status = RC522_ToCard(PCD_TRANSCEIVE,ucComMF522Buf,4,ucComMF522Buf,&unLen);
	if ((status == MI_OK) && (unLen == 0x90))
	{
		for (i=0; i<16; i++)
		{
			*(pData+i) = ucComMF522Buf[i];
		}
	}
	else
	{
		status = MI_ERR;
	}
	return status;
}
/*
函数功能：写卡函数
函数参数：addr 块地址
          *pData 写入的数据16字节
返回值  ：成功返回MI_OK
*/
char MFRC522_Write(uint8_t addr,uint8_t *pData)
{
	int8_t status;
	uint32_t unLen;
	uint8_t i,ucComMF522Buf[MAXRLEN]; 

	ucComMF522Buf[0] = PICC_WRITE;
	ucComMF522Buf[1] = addr;
	CalulateCRC(ucComMF522Buf,2,&ucComMF522Buf[2]);

	status = RC522_ToCard(PCD_TRANSCEIVE,ucComMF522Buf,4,ucComMF522Buf,&unLen);

	if ((status != MI_OK) || (unLen != 4) || ((ucComMF522Buf[0] & 0x0F) != 0x0A))
	{
		status = MI_ERR;
	}
		
	if (status == MI_OK)
	{
		for (i=0; i<16; i++)
		{
			ucComMF522Buf[i] = *(pData+i);
		}
		CalulateCRC(ucComMF522Buf,16,&ucComMF522Buf[16]);
		status = RC522_ToCard(PCD_TRANSCEIVE,ucComMF522Buf,18,ucComMF522Buf,&unLen);
		if ((status != MI_OK) || (unLen != 4) || ((ucComMF522Buf[0] & 0x0F) != 0x0A))
		{
			status = MI_ERR;
		}
	}

	return status;
}

/*
函数功能：设置RC522的工作方式
函数参数：type 工作模式
返回值  ：成功返回MI_OK
*/
char M500PcdConfigISOType(uint8_t type)
{
   if (type == 'A')   //ISO14443-A              
   { 
       RC522_Clear_Bit_Mask(Status2Reg,0x08);
       RC522_Write_Data(ModeReg,0x3D);
       RC522_Write_Data(RxSelReg,0x86);
       RC522_Write_Data(RFCfgReg,0x7F); 
   	   RC522_Write_Data(TReloadRegL,30);
	   RC522_Write_Data(TReloadRegH,0);
       RC522_Write_Data(TModeReg,0x8D);
	   RC522_Write_Data(TPrescalerReg,0x3E);
	   Delay_ms(10);
       RC522_Antenna_Open();
   }
   else{ return (char)-1; }  
   return MI_OK;
}

/*
函数功能：等待函数，等待卡片移开
函数参数：
返回值  ：
*/

void WaitCardOff(void)
{
	int8_t status;
	uint8_t	TagType[2];
 
	while(1)
	{
		status = MFRC522_Request(PICC_REQALL, TagType);
		if(status)
		{
			status = MFRC522_Request(PICC_REQALL, TagType);
			if(status)
			{
				status = MFRC522_Request(PICC_REQALL, TagType);
				if(status)
				{
					return;
				}
			}
		}
		Delay_ms(10);
	}
}

/*
函数功能：RFID初始化
函数参数：
返回值  ：
*/
void RFID_Init(void)									
{
	RC522_Init();											
    RC522_Reset();											
    RC522_Antenna_Close(); 	 								
    RC522_Antenna_Open();  									
	M500PcdConfigISOType('A');
}

/*
函数功能：RC522复位函数
函数参数：
返回值  ：
*/
void RC522_Reboot()
{
	RC522_Reset();
	RC522_Antenna_Close();
	RC522_Antenna_Open(); 
}