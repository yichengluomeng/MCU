#ifndef __RC522_H
#define __RC522_H

void RC522_Init();//初始化
uint8_t RC522_Read_Data(uint8_t Address);//RC522读取数据
void RC522_Write_Data(uint8_t Address,uint8_t Value);//RC522写入数据
uint8_t RC522_Reset();//RC522复位
void RC522_Set_Bit_Mask(uint8_t reg,uint8_t mask);//RC522置位
void RC522_Clear_Bit_Mask(uint8_t reg,uint8_t mask);//RC522清除置位
void RC522_Antenna_Open();//RC522开启天线
void RC522_Antenna_Close();//RC522关闭天线
void CalulateCRC(uint8_t *pIndata,uint8_t len,uint8_t *pOutData);//CRC校验
int8_t MFRC522_Halt(void);//让RC522休眠

int8_t MFRC522_Request(uint8_t req_code,uint8_t *pTagType);//寻卡

int8_t RC522_ToCard( uint8_t Command, 
					   uint8_t *pInData, 
					   uint8_t InLenByte,
					   uint8_t *pOutData, 
					   uint32_t  *pOutLenBit );//单片机通过RC522对ISO14443_A的通讯
					   
char MFRC522_Anticoll(uint8_t *pSnr);//防冲突
char MFRC522_SelectTag(uint8_t *pSnr);//选卡
char MFRC522_AuthState(uint8_t auth_mode,
					   uint8_t addr,
					   uint8_t *pKey,
					   uint8_t *pSnr);//验证密钥
char MFRC522_Read(uint8_t addr,uint8_t *pData);//读卡
char MFRC522_Write(uint8_t addr,uint8_t *pData);//写卡
char M500PcdConfigISOType(uint8_t type);//设置RC522工作模式为ISO14443-A模式
void WaitCardOff(void);//等待卡片移开
void RFID_Init(void);//初始化RC522
void RC522_Reboot();//重启RC522天线

#endif