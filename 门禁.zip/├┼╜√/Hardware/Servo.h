#ifndef __SERVO_H
#define __SERVO_H

void Servo_Init();

void PWM_SetCompare1(uint16_t Compare);

void Servo_SetAngle1(float Angle);

#endif