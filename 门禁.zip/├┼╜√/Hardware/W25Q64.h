#ifndef __W25Q64_H
#define __W25Q64_H

void W25Q64_Init();
void W25Q64_Write_Enable();
void W25Q64_ReadID(uint8_t *MID,uint16_t *DID);
void W25Q64_ReadBusy();
void W25Q64_Page_Progrom(uint32_t Address,uint8_t *Array,uint16_t Count);
void W25Q64_Sector_Ease(uint32_t Address);
void W25Q64_Read_Data(uint32_t Address,uint8_t *Array,uint32_t Count);

void Read_Card_ID();

#endif