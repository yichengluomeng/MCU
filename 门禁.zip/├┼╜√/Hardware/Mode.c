#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "RC522.h"
#include "RC522_Ins.h"
#include "Buzzer.h"
#include "W25Q64.h"
#include "Key.h"
#include "Servo.h"
#include "Delay.h"

extern uint8_t UID[4],Temp[4],UI0[4],UI1[4],UI2[4],UI3[4],UI4[4],UI5[4],UI6[4],UI7[4];
extern uint8_t i,KeyNum;
extern uint8_t Mode;
uint8_t Temp_card;
int8_t Card_ID;
uint8_t cardno;
int8_t Num;
void RC522_Check();
void Write_Card();
/*
函数功能:寻卡读卡
函数参数:
返回值  :
*/
void Request()
{
//	RC522_Reboot();

	OLED_ShowString(2,1,"MFRC522_Request");
	
	RC522_Check();
}

/*
函数功能:比较卡片
函数参数:
返回值  :比对成功返回对应卡片编号
		 比对失败返回其余编号		
		 未识别返回其余编号
*/
uint8_t Rc522Test(void)										
{
	//寻卡
    if (MFRC522_Request(PICC_REQALL, Temp) == MI_OK)
	{
		//防冲突
		if (MFRC522_Anticoll(UID) == MI_OK)
		{
			//用于调试
			for(i=0;i<4;i++)
			{
				OLED_ShowHexNum(3,1+(2*i),UID[i],2);
			}
//			cardno=0;	
			//比对卡片
			if(UID[0]==UI0[0]&&UID[1]==UI0[1]&&UID[2]==UI0[2]&&UID[3]==UI0[3])
			{
				cardno=1;
			}
			else if(UID[0]==UI1[0]&&UID[1]==UI1[1]&&UID[2]==UI1[2]&&UID[3]==UI1[3])
			{
				cardno=2;
			}
			else if(UID[0]==UI2[0]&&UID[1]==UI2[1]&&UID[2]==UI2[2]&&UID[3]==UI2[3])
			{
				cardno=3;
			}
			else if(UID[0]==UI3[0]&&UID[1]==UI3[1]&&UID[2]==UI3[2]&&UID[3]==UI3[3])
			{
				cardno=4;
			}
			//放冲突执行完毕，但未读取到卡片，表示卡片掉落或数据超出4个，可以添加定义的数组以及检查卡片
			else cardno = 0;
		}
		else cardno = 5;
	}
	else cardno = 6;
	return cardno;
}

/*
函数功能:读卡函数
函数参数:
返回值  :无返回值
		 读取正确的卡，蜂鸣器蜂鸣两声
		 读取错误的卡，蜂鸣器蜂连鸣
*/
void RC522_Check()									
{

	Card_ID = Rc522Test();	//获取卡编号
	if(Card_ID == 0)			//如果为0，表示“卡片错误”，系统中没有这张卡
	{
		OLED_ShowString(1,1,"   Error card   ");
		Buzzer_Alarm();		//蜂鸣器发出警报
	}
	else if(Card_ID==1||Card_ID==2||Card_ID==3||Card_ID == 4)			//如果卡编号为1-4，说明是系统中的4张卡
	{	
		OLED_ShowString(1,1,"The CardID is:  ");
		OLED_ShowNum(1,15,Card_ID,2);
		Buzzer2();			//蜂鸣器响两声
		Servo_SetAngle1(90);	//舵机旋转90度维持1.5秒
		Delay_ms(1500);
		Servo_SetAngle1(0);
	}	
}
/*
函数功能:写卡函数
函数参数:
返回值  :
		 
		 
*/
void Write()
{
	OLED_ShowString(2,1,"MFRC522_Write");
	Write_Card();
}

/*
函数功能:判断函数，判断是否有空位，当前卡是否录入
函数参数:
返回值  :
*/
void Find()
{
	if (MFRC522_Request(PICC_REQALL, Temp) == MI_OK)
	{
		if (MFRC522_Anticoll(UID) == MI_OK)
		{
			if(UI0[0] == 0xFF && UI0[1] == 0xFF && UI0[2] == 0xFF && UI0[3] == 0xFF) Temp_card = 1;	//判断系统各卡数据区是否为空，为空才能写入新卡
			else if(UI1[0] == 0xFF && UI1[1] == 0xFF && UI1[2] == 0xFF && UI1[3] == 0xFF) Temp_card = 2;
			else if(UI2[0] == 0xFF && UI2[1] == 0xFF && UI2[2] == 0xFF && UI2[3] == 0xFF) Temp_card = 3;
			else if(UI3[0] == 0xFF && UI3[1] == 0xFF && UI3[2] == 0xFF && UI3[3] == 0xFF) Temp_card = 4;
			else Temp_card = 5;
			
			if(UID[0]==UI0[0] && UID[1]==UI0[1] && UID[2]==UI0[2] && UID[3]==UI0[3])	//判断新卡是否已经录入
			{
				Temp_card = 6;
			}
			if(UID[0]==UI1[0] && UID[1]==UI1[1] && UID[2]==UI1[2] && UID[3]==UI1[3])
			{
				Temp_card = 6;
			}
			if(UID[0]==UI2[0] && UID[1]==UI2[1] && UID[2]==UI2[2] && UID[3]==UI2[3])
			{
				Temp_card = 6;
			}
			if(UID[0]==UI3[0] && UID[1]==UI3[1] && UID[2]==UI3[2] && UID[3]==UI3[3])
			{
				Temp_card = 6;
			}
		}
	}
}

void Write_Card()
{
	Find();
	if(Temp_card==1)
	{
		UI0[0] = UID[0];	//将新卡数据写入UI0[]数组
		UI0[1] = UID[1];
		UI0[2] = UID[2];
		UI0[3] = UID[3];
		W25Q64_Sector_Ease(0x000000);
		W25Q64_Page_Progrom(0x000000,UI0,4);
		OLED_ShowString(1,1,"  Add Card 1 OK ");	//写卡成功，蜂鸣器响一声
		Buzzer1();
	}
	
	if(Temp_card==2)
	{
		UI1[0] = UID[0];	//将新卡数据写入UI0[]数组
		UI1[1] = UID[1];
		UI1[2] = UID[2];
		UI1[3] = UID[3];
		W25Q64_Sector_Ease(0x01FF00);
		W25Q64_Page_Progrom(0x01FF00,UI1,4);
		OLED_ShowString(1,1,"  Add Card 2 OK ");	//写卡成功，蜂鸣器响一声
		Buzzer1();
	}
	
	if(Temp_card==3)
	{
		UI2[0] = UID[0];	//将新卡数据写入UI0[]数组
		UI2[1] = UID[1];
		UI2[2] = UID[2];
		UI2[3] = UID[3];
		W25Q64_Sector_Ease(0x02FF00);
		W25Q64_Page_Progrom(0x02FF00,UI2,4);
		OLED_ShowString(1,1,"  Add Card 3 OK ");	//写卡成功，蜂鸣器响一声
		Buzzer1();
	}
	
	if(Temp_card==4)
	{
		UI3[0] = UID[0];	//将新卡数据写入UI0[]数组
		UI3[1] = UID[1];
		UI3[2] = UID[2];
		UI3[3] = UID[3];
		W25Q64_Sector_Ease(0x03FF00);
		W25Q64_Page_Progrom(0x03FF00,UI3,4);
		OLED_ShowString(1,1,"  Add Card 4 OK ");	//写卡成功，蜂鸣器响一声
		Buzzer1();
	}
	
	if(Temp_card==5)
	{
		OLED_ShowString(1,1,"   NO memory    ");	//若4个存卡数组均已存入卡片则显示无数据空间，蜂鸣器发出警报
		Buzzer_Alarm();
	}
	
	if(Temp_card==6)
	{
		OLED_ShowString(1,1,"  Existing Card!  ");	//若4个存卡数组均已存入卡片则显示无数据空间，蜂鸣器发出警报
		Buzzer_Alarm();
	}
}    


void Delete_Card();

void Delete()
{
	OLED_ShowString(1,1,"  Delete Card:  ");
	Delete_Card();
}

void Selection()
{
	KeyNum=Key_GetKeyNumber();
	if(KeyNum==4)
	{
		Mode=1;
	}
	if(KeyNum==1)
	{
		Num++;
		if (Num>3)Num=4;
		OLED_ShowNum(3,10,Num,2);
		
	}
	if(KeyNum==2)
	{
		Num--;
		if (Num<0)Num=0;
		OLED_ShowNum(3,10,Num,2);
	}
}

void Delete_Card()
{
	Selection();
	if (Num==0)
	{
		if (KeyNum==3)
		{
			W25Q64_Sector_Ease(0x000000);
			UI0[0]=0xFF;
			UI0[1]=0xFF;
			UI0[2]=0xFF;
			UI0[3]=0xFF;
			OLED_ShowString(2,1,"Clear Card 1 OK ");
			Buzzer1();	//删除成功后蜂鸣器响一声
		}
	}
	
	if (Num==1)
	{
		if (KeyNum==3)
		{
			W25Q64_Sector_Ease(0x01FF00);
			UI1[0]=0xFF;
			UI1[1]=0xFF;
			UI1[2]=0xFF;
			UI1[3]=0xFF;
			OLED_ShowString(2,1,"Clear Card 2 OK ");
			Buzzer1();	//删除成功后蜂鸣器响一声
		}
	}
	
	if (Num==2)
	{
		if (KeyNum==3)
		{
			W25Q64_Sector_Ease(0x02FF00);
			UI2[0]=0xFF;
			UI2[1]=0xFF;
			UI2[2]=0xFF;
			UI2[3]=0xFF;
			OLED_ShowString(2,1,"Clear Card 3 OK ");
			Buzzer1();	//删除成功后蜂鸣器响一声
		}
	}
	
	if (Num==3)
	{
		if (KeyNum==3)
		{
			W25Q64_Sector_Ease(0x03FF00);
			UI3[0]=0xFF;
			UI3[1]=0xFF;
			UI3[2]=0xFF;
			UI3[3]=0xFF;
			OLED_ShowString(2,1,"Clear Card 4 OK ");
			Buzzer1();	//删除成功后蜂鸣器响一声
		}
	}
}