#ifndef __MODE_H
#define __MODE_H

void Request();
void Write();
void Delete();

#endif