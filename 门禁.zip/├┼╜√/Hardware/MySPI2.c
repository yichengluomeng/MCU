#include "stm32f10x.h"                  // Device header

void MySPI_W_SS2(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,(BitAction)BitValue);
}

void MySPI_W_SCK2(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_13,(BitAction)BitValue);
}

void MySPI_W_MOSI2(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_15,(BitAction)BitValue);
}

uint8_t MySPI_R_MISO2()
{
	return GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14);
}

void MySPI_Init2()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;//MOSI
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;//MISO
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13;//SS SCK
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
		
	MySPI_W_SS2(1);
	MySPI_W_SCK2(0);
//	MySPI_W_SCK(1);//模式3 模式2
}

void MySPI_Start2()
{
	MySPI_W_SS2(0);
}

void MySPI_Stop2()
{
	MySPI_W_SS2(1);
}

//模式0  符合手册时序图
uint8_t MySPI_SwapByte2(uint8_t Byte)
{
	uint8_t i, ReadByte = 0x00;
	for (i=0;i<8;i++)
	{
		MySPI_W_MOSI2(Byte&(0x80>>i));
		MySPI_W_SCK2(1);
		if (MySPI_R_MISO2()==1)ReadByte |= (0x80>>i);
		MySPI_W_SCK2(0);
	}
	return ReadByte;
}
/*
模式0
这种方法节省空间效率更高
通过将要发送的数据进行移位的方式
来使发送与接收同时在一个变量上
Byte<<=1;

uint8_t MySPI_SwapByte(uint8_t Byte)
{
	uint8_t i;
	for (i=0;i<8;i++)
	{
		MySPI_W_MOSI(Byte&0x80); 		   //取出要发送的数据的最高位,将其放置到移位寄存器
		Byte<<=1;				 		   //将要发送的数据右移1位，空出最低位
		MySPI_W_SCK(1);			 		   //时钟上升沿
		if (MySPI_R_MISO()==1)Byte |= 0x01;//如果从机发送的这位数据为1
										   //将其取出放置到Byte最低位上
		MySPI_W_SCK(0);					   //时钟下降沿
	}
	return Byte;						   //返回数据
}
*/

/*
模式1
uint8_t MySPI_SwapByte(uint8_t Byte)
{
	uint8_t i, ReadByte = 0x00;
	for (i=0;i<8;i++)
	{
		MySPI_W_SCK(1);
		MySPI_W_MOSI(Byte&(0x80>>i));
		MySPI_W_SCK(0);
		if (MySPI_R_MISO()==1)ReadByte |= (0x80>>i);
	}
	return ReadByte;
}
*/

/*
模式2
uint8_t MySPI_SwapByte(uint8_t Byte)
{
	uint8_t i, ReadByte = 0x00;
	for (i=0;i<8;i++)
	{
		MySPI_W_MOSI(Byte&(0x80>>i));
		MySPI_W_SCK(0);
		if (MySPI_R_MISO()==1)ReadByte |= (0x80>>i);
		MySPI_W_SCK(1);
	}
	return ReadByte;
}
*/

/*
模式3
uint8_t MySPI_SwapByte(uint8_t Byte)
{
	uint8_t i, ReadByte = 0x00;
	for (i=0;i<8;i++)
	{
		MySPI_W_SCK(0);
		MySPI_W_MOSI(Byte&(0x80>>i));
		MySPI_W_SCK(1);
		if (MySPI_R_MISO()==1)ReadByte |= (0x80>>i);
	}
	return ReadByte;
}
*/