#ifndef __MYSPI2_H
#define __MYSPI2_H

void MySPI_Init2();
void MySPI_Start2();
void MySPI_Stop2();
uint8_t MySPI_SwapByte2(uint8_t Byte);

#endif