#include "stm32f10x.h"                  // Device header
#include "MySPI2.h"
#include "W25Q64_Ins.h"

extern uint8_t UI0[4];							
extern uint8_t UI1[4];							
extern uint8_t UI2[4];							
extern uint8_t UI3[4];
extern uint8_t UI4[4];							
extern uint8_t UI5[4];							
extern uint8_t UI6[4];							
extern uint8_t UI7[4];

/*
函数功能：初始化W25Q64的底层PWM
函数参数：
返回值  ：
*/
void W25Q64_Init()
{
	MySPI_Init2();
}

/*
函数功能：读取W25Q64的器件ID
函数参数：*MID厂商ID
		  *DID器件ID
返回值  ：
*/
void W25Q64_ReadID(uint8_t *MID,uint16_t *DID)
{
	MySPI_Start2();
	MySPI_SwapByte2(W25Q64_JEDEC_ID);
	*MID = MySPI_SwapByte2(W25Q64_DUMMY_BYTE);
	*DID = MySPI_SwapByte2(W25Q64_DUMMY_BYTE);
	*DID <<=8;
	*DID |= MySPI_SwapByte2(W25Q64_DUMMY_BYTE);
	MySPI_Stop2();
}

/*
函数功能：W25Q64的写使能
函数参数：
返回值  ：
*/
void W25Q64_Write_Enable()
{
	MySPI_Start2();
	MySPI_SwapByte2(W25Q64_WRITE_ENABLE);
	MySPI_Stop2();
}

/*
函数功能：W25Q64的查询忙状态
函数参数：
返回值  ：
*/
void W25Q64_ReadBusy()
{
	uint32_t Time;
	MySPI_Start2();
	MySPI_SwapByte2(W25Q64_READ_STATUS_REGISTER_1);
	Time = 100000;
	while((MySPI_SwapByte2(W25Q64_DUMMY_BYTE)&0x01)==0x01)
	{
		Time--;
		if (Time==0)break;
	}
	MySPI_Stop2();
}

/*
函数功能：W25Q64的页写
函数参数：Address 写入的地址
		  *Array 写入数据
		  Count 写入多少个数据
返回值  ：
*/
void W25Q64_Page_Progrom(uint32_t Address,uint8_t *Array,uint16_t Count)
{
	uint32_t i;
	W25Q64_Write_Enable();
	MySPI_Start2();
	MySPI_SwapByte2(W25Q64_PAGE_PROGRAM);
	MySPI_SwapByte2(Address>>16);
	MySPI_SwapByte2(Address>>8);
	MySPI_SwapByte2(Address);
	for (i=0;i<Count;i++)
	{
		MySPI_SwapByte2(Array[i]);
	}
	MySPI_Stop2();
	W25Q64_ReadBusy();	
}

/*
函数功能：W25Q64的页擦除
函数参数：Address 擦除的地址
返回值  ：
*/
void W25Q64_Sector_Ease(uint32_t Address)
{
	W25Q64_Write_Enable();
	MySPI_Start2();
	MySPI_SwapByte2(W25Q64_SECTOR_ERASE_4KB);
	MySPI_SwapByte2(Address>>16);
	MySPI_SwapByte2(Address>>8);
	MySPI_SwapByte2(Address);
	MySPI_Stop2();
	W25Q64_ReadBusy();	
}

/*
函数功能：W25Q64的读取
函数参数：Address 读取的地址
          *Array  读取的数据
           Count  读取多少个数据
返回值  ：*Array读取的数据
*/
void W25Q64_Read_Data(uint32_t Address,uint8_t *Array,uint32_t Count)
{
	uint32_t i;
	MySPI_Start2();
	MySPI_SwapByte2(W25Q64_READ_DATA);
	MySPI_SwapByte2(Address>>16);
	MySPI_SwapByte2(Address>>8);
	MySPI_SwapByte2(Address);
	for (i=0;i<Count;i++)
	{
		Array[i]=MySPI_SwapByte2(W25Q64_DUMMY_BYTE);
	}
	MySPI_Stop2();	
}

/*
函数功能：读取卡片ID
函数参数：
返回值  ：读取的数据
*/
void Read_Card_ID()
{
	W25Q64_Read_Data(0x000000,UI0,4);
	
	W25Q64_Read_Data(0x01FF00,UI1,4);
	
	W25Q64_Read_Data(0x02FF00,UI2,4);
	
	W25Q64_Read_Data(0x03FF00,UI3,4);
//	
//	W25Q64_Read_Data(0x000000,UI4,4);
//	
//	W25Q64_Read_Data(0x000000,UI5,4);
//	
//	W25Q64_Read_Data(0x000000,UI6,4);
//	
//	W25Q64_Read_Data(0x000000,UI7,4);
}