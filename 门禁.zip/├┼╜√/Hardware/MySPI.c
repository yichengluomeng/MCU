#include "stm32f10x.h"                  // Device header
void MySPI_W_SS(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_4,(BitAction)BitValue);
}

void MySPI_W_SCK(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_5,(BitAction)BitValue);
}

void MySPI_W_MOSI(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_7,(BitAction)BitValue);
}

uint8_t MySPI_R_MISO()
{
	return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6);
}

void MySPI_W_RESET(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOB,GPIO_Pin_0,(BitAction)BitValue);
}

void MySPI_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;//MOSI
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;//MISO
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;//SS SCK
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	MySPI_W_SS(1);
	MySPI_W_SCK(0);

}

void MySPI_Start()
{
	MySPI_W_SS(0);
}

void MySPI_Stop()
{
	MySPI_W_SS(1);
}

//读取数据
uint8_t MySPI_ReadByte()
{
	uint8_t i, ReadByte = 0x00;
	for (i=0;i<8;i++)
	{
		MySPI_W_SCK(1);
		if (MySPI_R_MISO()==1)ReadByte |= (0x80>>i);
		MySPI_W_SCK(0);
	}
	return ReadByte;
}

//写入数据
void MySPI_WriteByte(uint8_t Byte)
{
	uint8_t i, ReadByte = 0x00;
	for (i=0;i<8;i++)
	{
		MySPI_W_MOSI(Byte&(0x80>>i));
		MySPI_W_SCK(1);
		MySPI_W_SCK(0);
	}
}


