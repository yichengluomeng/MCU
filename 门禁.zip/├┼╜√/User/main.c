#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "RC522.h"
#include "RC522_Ins.h"
#include "W25Q64.h"
#include "Key.h"
#include "TIM3.h"
#include "Buzzer.h"
#include "Mode.h"
#include "Servo.h"

void MainLoop(void);

unsigned char buf[20];  

uint8_t Key[4] = {0xFF,0xFF,0xFF,0xFF};

uint8_t UI0[4];
uint8_t UID[4],Temp[4],UI1[4],UI2[4],UI3[4],UI4[4],UI5[4],UI6[4],UI7[4];
uint8_t i,KeyNum = 1;
uint8_t Mode;

char a;

int main(void)
{
	OLED_Init();
	RC522_Init();
	W25Q64_Init();
	TIM3_Init();
	Key_Init();
	Buzzer_Init();
	Servo_Init();
	TIM3_SetIRQHandler(MainLoop);	
	Read_Card_ID();
	RC522_Reboot();
	while (1)
	{
		Read_Card_ID();
		for(i=0;i<4;i++)
		{
			OLED_ShowHexNum(4,1+(2*i),UI1[i],2);
		}
		KeyNum=Key_GetKeyNumber();
		/*模式选择*/
		if(KeyNum == 1)Mode = 1;
		if(KeyNum == 2)Mode = 2;
		if(KeyNum == 3)Mode = 3;
		if(KeyNum == 4)Mode = 4;
		
		if (Mode == 1)//寻卡
		{
			Request();
		}
		if (KeyNum == 2)//写卡
		{
			Write();
		}
		if (KeyNum == 3)//删卡
		{
			while(1)
			{
				Delete();
				if(KeyNum==4)break;
			}	
		}		
	}
}

void MainLoop(void)
{
	static uint16_t LoopCount[1];
	LoopCount[0]++;
	
	if(LoopCount[0]>=20)
	{
		LoopCount[0]=0;
		Key_Loop();
	}
}