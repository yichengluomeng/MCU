#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MYDMA.h"
#include "AD.h"

//uint8_t DataA[] = {0x01, 0x02, 0x03, 0x04};				
//uint8_t DataB[] = {};	
//uint16_t AD_Value[4];
	
int main(void)
{
	OLED_Init();
	
	AD_Init();
//	My_DMAInit(Get_Value(ADC_Channel_0),(uint32_t) DataB,4);
	
//	OLED_ShowString(1, 1, "DataA");
//	OLED_ShowString(3, 1, "DataB");
//	
//	OLED_ShowHexNum(1, 8, (uint32_t)DataA, 8);
//	OLED_ShowHexNum(3, 8, (uint32_t)DataB, 8);
	
	while (1)
	{
//		Get_Value();
		
		
//		DataA[0] ++;		
//		DataA[1] ++;
//		DataA[2] ++;
//		DataA[3] ++;
//		
//		OLED_ShowHexNum(2, 1, DataA[0], 2);		
//		OLED_ShowHexNum(2, 4, DataA[1], 2);
//		OLED_ShowHexNum(2, 7, DataA[2], 2);
//		OLED_ShowHexNum(2, 10, DataA[3], 2);
//		OLED_ShowHexNum(4, 1, DataB[0], 2);		
//		OLED_ShowHexNum(4, 4, DataB[1], 2);
//		OLED_ShowHexNum(4, 7, DataB[2], 2);
//		OLED_ShowHexNum(4, 10, DataB[3], 2);
//		
//		Delay_ms(1000);
//		
//		MyDMA_Transfer();
//		
//		OLED_ShowHexNum(2, 1, DataA[0], 2);		
//		OLED_ShowHexNum(2, 4, DataA[1], 2);
//		OLED_ShowHexNum(2, 7, DataA[2], 2);
//		OLED_ShowHexNum(2, 10, DataA[3], 2);
		OLED_ShowNum(1, 1, AD_Value[0], 5);		
		OLED_ShowNum(2, 1, AD_Value[1], 5);
		OLED_ShowNum(3, 1, AD_Value[2], 5);
		OLED_ShowNum(4, 1, AD_Value[3], 5);
		OLED_ShowNum(1, 7, AD_Value[4], 5);		
		OLED_ShowNum(2, 7, AD_Value[5], 5);
		OLED_ShowNum(3, 7, AD_Value[6], 5);
//		OLED_ShowNum(4, 7, AD_Value[7], 5);
//		
//		Delay_ms(1000);
		
	}
}
