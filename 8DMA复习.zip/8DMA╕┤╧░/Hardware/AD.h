#ifndef __AD_H
#define __AD_H

extern uint16_t AD_Value[7];

void AD_Init();
void Get_Value();

#endif