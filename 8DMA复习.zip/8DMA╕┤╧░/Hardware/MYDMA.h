#ifndef __MYDMA_H
#define __MYDMA_H

void My_DMAInit(uint32_t AddrA,uint32_t AddrB,uint16_t Size);
void MyDMA_Transfer();

#endif