#ifndef __BLUETOOTH_H
#define __BLUETOOTH_H

#include <stdio.h>

extern char Bluetooth_RxPacket[];
extern uint8_t Bluetooth_RxFlag;

void Bluetooth_Init();

void Bluetooth_SendByte(uint8_t Byte);
void Bluetooth_SendArray(uint8_t *Array , uint8_t Length);
void Bluetooth_SendString(char *String);
void Bluetooth_SendNum(uint32_t Num, uint8_t Length);

void Bluetooth_Sendtext(char *String);

int fputc(int ch, FILE *f);
void Bluetooth_Printf(char *format, ...);

uint8_t Bluetooth_GetRxFlag();
uint8_t Bluetooth_GetRxData();
uint8_t Bluetooth_ReadData();
uint8_t Key_GetKeyNumber();

#endif