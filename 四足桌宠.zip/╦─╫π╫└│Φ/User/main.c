#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MODE.h"
#include "Servo.h"
#include "Serial.h"
#include <stdlib.h>
#include "Auto_OR_Man.h"
#include "Ultrasound.h"
#include "Voice.h"

uint8_t Mode1,Mode2;//接收蓝牙和语音模块的数据
uint8_t Mode;//模式切换
uint16_t interval;//用以对OLED表情切换计数
uint16_t interva2;//用以对OLED表情切换计数
float distance;//超声波返回的距离

int main(void)
{
	OLED_Init();//初始化OLED
	MODE_Init();//初始化舵机运行模式
	Bluetooth_Init();//初始化蓝牙摸块
	Ultrasound_Init();//初始化超声波模块
	Voice_Init();//初始化语音模块
	MODE_Attention();
	while (1)
	{	
		Mode1 = Bluetooth_GetRxData();
		Mode2 = Voice_GetRxData();
		if (Bluetooth_GetRxFlag()==1)//检测是否有蓝牙信号传输
		{
			Mode = Mode1;//获取串口接受的数据
		}
		else if ((Voice_GetRxFlag()==1))//检测是否有语音信号传输
		{
			Mode = Mode2;
		}
		if (Mode=='G')//判断串口发送的数据是什么来进行模式的切换
		{
			Auto(); //自动模式
		}
		else
		{
			Man();//手动模式
		}		
	}
}