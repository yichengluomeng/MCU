#ifndef __TIMER3_H
#define __TIMER3_H

void TIM3_Init();

#endif