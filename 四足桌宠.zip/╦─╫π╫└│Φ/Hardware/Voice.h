#ifndef __VOICE_H
#define __VOICE_H
#include <stdio.h>

void Voice_Init(void);
void Voice_SendByte(uint8_t Byte);
void Voice_SendArray(uint8_t *Array, uint16_t Length);
void Voice_SendString(char *String);
void Voice_SendNumber(uint32_t Number, uint8_t Length);
void Voice_Printf(char *format, ...);

uint8_t Voice_GetRxFlag(void);
uint8_t Voice_GetRxData(void);

#endif