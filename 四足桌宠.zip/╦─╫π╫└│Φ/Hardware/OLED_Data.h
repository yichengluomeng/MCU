#ifndef __OLED_DATA_H
#define __OLED_DATA_H

#include <stdint.h>

/*字符集定义*/
/*以下两个宏定义只可解除其中一个的注释*/
#define OLED_CHARSET_UTF8			//定义字符集为UTF8
//#define OLED_CHARSET_GB2312		//定义字符集为GB2312

/*字模基本单元*/
typedef struct 
{
	
#ifdef OLED_CHARSET_UTF8			//定义字符集为UTF8
	char Index[5];					//汉字索引，空间为5字节
#endif
	
#ifdef OLED_CHARSET_GB2312			//定义字符集为GB2312
	char Index[3];					//汉字索引，空间为3字节
#endif
	
	uint8_t Data[32];				//字模数据
} ChineseCell_t;

/*ASCII字模数据声明*/
extern const uint8_t OLED_F8x16[][16];
extern const uint8_t OLED_F6x8[][6];

/*汉字字模数据声明*/
extern const ChineseCell_t OLED_CF16x16[];

/*图像数据声明*/
extern const uint8_t Diode[];			//二极管
extern const uint8_t A[];               //测试A
extern const uint8_t Attention_1[];     //立正1
extern const uint8_t Attention_2[];     //立正2
extern const uint8_t Advance_1[];       //前进1
extern const uint8_t Advance_2[];       //前进2
extern const uint8_t Advance_3[];       //前进3
extern const uint8_t Advance_4[];       //前进4
extern const uint8_t Grievance[];       //委屈
extern const uint8_t Left[];            //左转
extern const uint8_t Right[];           //右转
extern const uint8_t Beckon1[];         //招手1
extern const uint8_t Beckon2[];         //招手2
extern const uint8_t Beckon3[];         //招手3
extern const uint8_t Beckon4[];         //招手4
extern const uint8_t B[];               //测试B
//extern const uint8_t C[];
/*按照上面的格式，在这个位置加入新的图像数据声明*/
//...

#endif


/*****************江协科技|版权所有****************/
/*****************jiangxiekeji.com*****************/
