#include "stm32f10x.h"                  // Device header
#include "move.h"
#include "OLED.h"
#include "Ultrasound.h"

extern uint16_t interval;//用于记录当前状态时间，进行修改脸部数据，
extern uint16_t interva2;//用于记录当前状态时间，进行修改脸部数据，
/*
眨眼逻辑
num	   :眨眼间隔
Image1 :显示数组1
Image2 :显示数组2
Image3 :显示数组3
Image4 :显示数组4
设置多组眨眼切换函数用于多个不同动作表情的切换
*/

void Blinkk_1(const uint8_t *Image1)
{
	OLED_ShowImage(1,1,128,128,Image1);				//OLED显示特定数据
	OLED_Update();								    //更新OLED
}

void Blinkk_2(uint8_t num,const uint8_t *Image1,const uint8_t *Image2)
{	
	//通过if判断来进行表情的切换
	if (interval<=num)
	{
		OLED_ShowImage(1,1,128,128,Image1);//显示数组1
		if (interval==num)//超过设定值，更换下一个数组
		{
			interval+=num;
		}
		interval++;//间隔+
	}
	else if (interval>=num)
	{
		OLED_ShowImage(1,1,128,128,Image2);//显示数组2
		interval--;
		if (interval==num)//小于设定值，更换下一个数组
		{
			interval-=num;
		}
	}
	OLED_Update(); //更新OLED
}
void Blinkk_3(const uint8_t *Image1,const uint8_t *Image2,const uint8_t *Image3)
{
	if(interva2>90)interva2=0;//防止多个间隔函数冲突
	if (interva2<=30)
	{
		OLED_ShowImage(1,1,128,128,Image1);
		interva2++;
	}
	else if (interva2<=60)
	{
		OLED_ShowImage(1,1,128,128,Image2);
		interva2++;
	}
	else if (interva2<=90)
	{
		OLED_ShowImage(1,1,128,128,Image3);	
		if (interva2==90)
		{
			interva2-=90;
		}
		interva2++;
	}
	OLED_Update();
}
void Blinkk_4(const uint8_t *Image1,const uint8_t *Image2,const uint8_t *Image3,const uint8_t *Image4)
{
	if(interva2>4)interva2=0;
	if (interva2<=1)
	{
		OLED_ShowImage(1,1,128,128,Image1);
		interva2++;
	}
	else if (interva2<=2)
	{
		OLED_ShowImage(1,1,128,128,Image2);
		interva2++;
	}
	else if (interva2<=3)
	{
		OLED_ShowImage(1,1,128,128,Image3);
		interva2++;
	}
	else if (interva2<=4)
	{
		OLED_ShowImage(1,1,128,128,Image4);
		interva2++;
		if (interva2==5)
		{
			interva2-=4;
		}
	}
	OLED_Update();
}

//舵机初始化
void MODE_Init()
{
	Move_Init(); 									  //初始化底层
}
//前进初始化
void MODE_Advance()
{
	//添加动作表情
	Blinkk_4(Advance_1,Advance_2,Advance_3,Advance_4);//眨眼动作
	Move_advance();									  //运动方式
	//可以在这里进行计数获取动作时间以及次数
	/*后续添加心情体力等数值，使其更加生动*/
}
//后退初始化
void MODE_Retreat()
{
	Blinkk_4(Advance_1,Advance_2,Advance_3,Advance_4);//眨眼动作
	Move_retreat();									  //运动方式
}
//右转初始化
void MODE_Right()
{
	Blinkk_1(Right);								 //眨眼动作
	Move_right();									 //运动方式
}
//左转初始化
void MODE_Left()
{
	Blinkk_1(Left);								     //眨眼动作
	Move_left();   								     //运动方式
}
//立正初始化
void MODE_Attention()
{
	Blinkk_2(20,Attention_1,Attention_2);            //眨眼动作
	Move_attention();            					 //运动方式
}
//招手初始化
void MODE_Beckon()
{
	Blinkk_4(Beckon1,Beckon4,Beckon2,Beckon3);        //眨眼动作
	Move_beckon();                                    //运动方式
}
//摇摆初始化
void MODE_Sway()
{
	Blinkk_1(Grievance);                              //眨眼动作
	Move_sway();                                      //运动方式
}
//避障初始化
void MODE_Ultrasound()
{
	float distance;//超声波返回距离
	distance = Ultrasound_GetNum();//获取超声波返回距离
	if (distance>10)//在10cm以上执行空函数
	{
		
	}
	else//在10cm以内
	{
		while (distance<15)//如果一直在15cm以内，执行while循环
		{
			MODE_Right();//让其右转避开障碍物
			distance = Ultrasound_GetNum();//再次获取超声波距离
			if(distance>15)break;//如果在15cm以外了，退出While
		}
	}
}