#include "stm32f10x.h"                  // Device header
#include "Timer3.h"
#include "Delay.h"
#include "OLED.h"

uint16_t Num;//超声波计数

void Ultrasound_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//Trig发送8个40KHz超声波
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//Echo接收返回超声波
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	TIM3_Init();//初始化定时中断
}

//开启定时器开始计数
void Ultrasound_Open()
{
	TIM_SetCounter(TIM3,0);
	Num=0;
	TIM_Cmd(TIM3,ENABLE);
}

//关闭定时器
void Ultrasound_Close()
{
	TIM_Cmd(TIM3,DISABLE);
}

//返回超声避障距离
uint16_t Ultrasound_GetTrigNum()
{
	uint16_t t;
	t=Num*1000;//将计数值*1000再加上TIM内现在的计数值，以获取总共计数多少
	t+=TIM_GetCounter(TIM3);//将计数值*1000再加上TIM内现在的计数值，以获取总共计数多少
	TIM_SetCounter(TIM3,0);//清零定时器的计数器，以便下次使用
	Delay_ms(50);//
	return t;
}

float Ultrasound_GetNum()
{
	uint16_t t;//获取超声避障距离
	uint8_t i = 0;//多次计数取平均
	float lengthTemp = 0;//中间数据
    float sum = 0;//总和
	while(i<5)//记录5次
	{
		GPIO_WriteBit(GPIOA, GPIO_Pin_6,1);//开启超声避障
		Delay_us(20);                      //开启超声避障
		GPIO_WriteBit(GPIOA, GPIO_Pin_6,0);//开启超声避障
		//检测到超声避障接收引脚由0变1时，开始计数
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 0);
		Ultrasound_Open();//开启定时器
		i++;
		//检测到超声避障接收引脚由1变0时，超声波返回完毕，关闭定时器
		while(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7) == 1);
		Ultrasound_Close();//关闭定时器
		t = Ultrasound_GetTrigNum();//获取当前超声波的距离
		lengthTemp = ((float)t/58.0);//58um对应1cm
		sum = lengthTemp + sum;//累加和
	}
	lengthTemp=sum/5.0;//求5次平均
	return lengthTemp;//返回距离
}