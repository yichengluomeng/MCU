#ifndef __ATUO_OR_MAN_
#define __ATUO_OR_MAN_

void Auto();//自动
void Man(); //手动

#endif