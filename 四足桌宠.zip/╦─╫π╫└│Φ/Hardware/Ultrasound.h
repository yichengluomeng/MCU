#ifndef __ULTRASONIC_H
#define __ULTRASONIC_H

void Ultrasound_Init();
void Ultrasound_Open();
void Ultrasound_Close();
uint16_t Ultrasound_GetTrigNum();
float Ultrasound_GetNum();

#endif