#ifndef __MOVE_H
#define __MOVE_H

void Move_Init();//初始化PWM底层
void Move_advance();//前进
void Move_attention();//立正
void Move_retreat();//后退
void Move_left();//左转
void Move_right();//右转
void Move_beckon();//招手
void Move_sway();//摇摆

#endif