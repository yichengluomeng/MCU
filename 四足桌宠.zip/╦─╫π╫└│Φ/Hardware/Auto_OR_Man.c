#include "stm32f10x.h"                  // Device header
#include <stdlib.h>
#include "OLED.h"
#include "MODE.h"

extern uint8_t Mode;
uint8_t Ultrasound_Flag;

/*
随机数产生函数，用于模拟随机移动
给产生的随机数赋予一个新的权重，每个权重所运行的动作不同
*/
uint16_t random()
{
	uint16_t num=0;
	return num=rand()%700+1;
}

/*
避障模式

*/

void Obstacle_avoidance()
{
	if (Mode=='U')			//开启避障模式
	{
		Ultrasound_Flag=1;  //避障模式标志位
	}
	if (Mode=='V')			//关闭避障模式
	{
		Ultrasound_Flag=0;  //避障模式标志位
	}
	if(Ultrasound_Flag==1)
	{
		MODE_Ultrasound();  //避障模式
	}
}
	
/*
自动函数
这样的解决方式并不太好，希望能有大佬给解惑
*/
void Auto()
{
	uint16_t weight;
	weight = random();
	if (weight<200)MODE_Attention();
	else if (weight<380)MODE_Advance();
	else if (weight<560)MODE_Retreat();
	else if (weight<620)MODE_Right();
	else if (weight<680)MODE_Left();
	else if (weight<690)MODE_Beckon();
	else if (weight<=700)MODE_Sway();
}

/*
手动模式
如果有添加的新的函数可以在这里进行添加判断
*/
void Man()
{
	
	Obstacle_avoidance();	//避障模式
	
	if (Mode=='A')
	{
		MODE_Advance();		//前进模式
	}
	else if (Mode=='B')     
	{
		MODE_Retreat();     //后退模式
	}
	else if (Mode=='C')      
	{                         
		MODE_Left();        //左转模式
	}
	else if (Mode=='D')
	{
		MODE_Right();       //右转模式
	}
	else if (Mode=='S')
	{
		MODE_Attention();   //停止模式
	}                         
	else if (Mode=='E')       
	{                         
		MODE_Sway();        //委屈模式
	}                         
	else if (Mode=='F')        
	{                           
		MODE_Beckon();      //招手模式
	}                         
                              
}                             
                           