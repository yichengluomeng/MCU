#include "stm32f10x.h"                  // Device header
#include "Servo.h"
#include "Delay.h"

/*
该程序为舵机的底层动作函数
可以通过修改对应函数以对动作进行修改
可以添加其余动作丰富你的设计
*/

/*
	Servo_SetAngle1(); PA0 左后
	Servo_SetAngle3(); PA2 右前
	Servo_SetAngle2(); PA1 右后
	Servo_SetAngle4(); PA3 左前
	上述舵机应对应实际进行修改
*/

void Move_Init()//初始化底层PWM
{
	Servo_Init();
}

void Move_advance()//前进
{
	Servo_SetAngle1(90);    //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(135);    //PA1 右后
	Servo_SetAngle4(45);    //PA3 左前	
	
	Delay_ms(150);
	
	Servo_SetAngle1(135);    //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(135);    //PA1 右后	
	Servo_SetAngle4(45);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(135);    //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(90);    //PA1 右后
	Servo_SetAngle4(90);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(90);	 //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(90);	 //PA1 右后	
	Servo_SetAngle4(90);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(45);    //PA0 左后
	Servo_SetAngle3(135);    //PA2 右前
	Servo_SetAngle2(90);    //PA1 右后
	Servo_SetAngle4(90);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(45);    //PA0 左后
	Servo_SetAngle3(135);    //PA2 右前
	Servo_SetAngle2(45);    //PA1 右后	
	Servo_SetAngle4(135);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(90);    //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(45);    //PA1 右后	
	Servo_SetAngle4(135);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(90);	 //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(90);	 //PA1 右后	
	Servo_SetAngle4(90);    //PA3 左前
	
	Delay_ms(150);
}

void Move_retreat()//后退
{
	Servo_SetAngle1(90);    //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(45);    //PA1 右后
	Servo_SetAngle4(135);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(45);    //PA0 左后
	Servo_SetAngle3(135);    //PA2 右前
	Servo_SetAngle2(45);    //PA1 右后
	Servo_SetAngle4(135);    //PA3 左前	
	
	Delay_ms(150);
	
	Servo_SetAngle1(45);    //PA0 左后
	Servo_SetAngle3(135);    //PA2 右前
	Servo_SetAngle2(90);    //PA1 右后
	Servo_SetAngle4(90);    //PA3 左前	
	
	Delay_ms(150);
	
	Servo_SetAngle1(90);	 //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(90);	 //PA1 右后	
	Servo_SetAngle4(90);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(135);   //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前	
	
	Delay_ms(150);
	
	Servo_SetAngle1(135);   //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(135);   //PA1 右后
	Servo_SetAngle4(45);   //PA3 左前	
	
	Delay_ms(150);
	
	Servo_SetAngle1(90);    //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(135);    //PA1 右后	
	Servo_SetAngle4(45);    //PA3 左前
	
	Delay_ms(150);
	
	Servo_SetAngle1(90);	 //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(90);	 //PA1 右后	
	Servo_SetAngle4(90);    //PA3 左前
	
	Delay_ms(150);
}
void Move_right()//右转
{
	Servo_SetAngle1(45);   //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前	
	Delay_ms(150);
	
	Servo_SetAngle1(45);   //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(135);   //PA1 右后
	Servo_SetAngle4(135);   //PA3 左前		
	Delay_ms(150);
	
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(135);   //PA1 右后
	Servo_SetAngle4(135);   //PA3 左前	
	Delay_ms(150);
	
	Servo_SetAngle1(90);
	Servo_SetAngle3(90);
	Servo_SetAngle2(90);
	Servo_SetAngle4(90);
	Delay_ms(150);
}

void Move_left()//左转
{
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(135);   //PA1 右后
	Servo_SetAngle4(135);   //PA3 左前	
	Delay_ms(150);
	
	Servo_SetAngle1(45);   //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(135);   //PA1 右后
	Servo_SetAngle4(135);   //PA3 左前	
	Delay_ms(150);
	
	Servo_SetAngle1(45);   //PA0 左后
	Servo_SetAngle3(45);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前	
	Delay_ms(150);
	
	Servo_SetAngle1(90);
	Servo_SetAngle3(90);
	Servo_SetAngle2(90);
	Servo_SetAngle4(90);
	Delay_ms(150);
}

void Move_attention()//立正
{
	PWM_SetCompare1(1500);
	PWM_SetCompare3(1500);
	PWM_SetCompare2(1500);
	PWM_SetCompare4(1500);
}

void Move_beckon()//招手
{
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(115);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前
	Delay_ms(150);
	
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(135);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前
	Delay_ms(150);
	
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(155);  //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前
	Delay_ms(150);
	
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(135);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前
	Delay_ms(150);
}

void Move_sway()//摇摆
{
	Servo_SetAngle1(45);   //PA0 左后
	Servo_SetAngle3(135);    //PA2 右前
	Servo_SetAngle2(135);   //PA1 右后
	Servo_SetAngle4(45);   //PA3 左前	
	Delay_ms(150);
	
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前
	Delay_ms(150);
	
	Servo_SetAngle1(135);   //PA0 左后
	Servo_SetAngle3(45);  //PA2 右前
	Servo_SetAngle2(45);   //PA1 右后
	Servo_SetAngle4(135);   //PA3 左前
	Delay_ms(150);
	
	Servo_SetAngle1(90);   //PA0 左后
	Servo_SetAngle3(90);    //PA2 右前
	Servo_SetAngle2(90);   //PA1 右后
	Servo_SetAngle4(90);   //PA3 左前
	Delay_ms(150);
}