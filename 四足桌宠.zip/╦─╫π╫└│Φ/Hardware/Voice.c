#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>

uint8_t Voice_RxData;		//定义串口接收的数据变量
uint8_t Voice_RxFlag;		


void Voice_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//TX输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);					
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//RX输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);					
	
	USART_InitTypeDef USART_InitStructure;					
	USART_InitStructure.USART_BaudRate = 9600;				//波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;	//不使用流控
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;	//工作在发送与接收模式
	USART_InitStructure.USART_Parity = USART_Parity_No;		//奇偶校验
	USART_InitStructure.USART_StopBits = USART_StopBits_1;	//一位停止位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;	//八位数据位	
	USART_Init(USART3, &USART_InitStructure);				
	
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);			
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);			
	
	NVIC_InitTypeDef NVIC_InitStructure;					
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;		
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;		
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;		
	NVIC_Init(&NVIC_InitStructure);							

	USART_Cmd(USART3, ENABLE);								
}

/*
语音模块发送一个字节的函数
形参
Byte：发送的字节
*/
void Voice_SendByte(uint8_t Byte)
{
	USART_SendData(USART3, Byte);		
	while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);	

}

/*
语音模块发送一个数组的函数
形参
*Array：数组的地址
Length：该数组有多少个参数
*/
void Voice_SendArray(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)//循环调用发送字节函数，将数组中的数据依次发送		
	{
		Voice_SendByte(Array[i]);		
	}
}

/*
蓝牙发送字符串的函数
形参
*String：发送字符串的地址
*/
void Voice_SendString(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)//循环调用发送字节函数，将字符串中的数据依次发送
	{
		Voice_SendByte(String[i]);		
	}
}

/*
取次方的函数
返回X的Y次方
*/
uint32_t Voice_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;	
	while (Y --)			
	{
		Result *= X;		
	}
	return Result;
}

/*
蓝牙发送数字的函数
形参
Num：发送的数字
Length：发送数字的个数

实现思路：
以Num为12345为例
Length=5	
取次方函数 Serial_Pow(10, Length - i - 1)=10^4=10000		Length - i - 1=4
12345/10000=1		1%10=1

Length=4	
取次方函数 Serial_Pow(10, Length - i - 1)=10^3=1000		Length - i - 1=3
12345/1000=12		12%10=2
……………………
加上'0'，在ASCLL码中进行位移0位……
*/
void Voice_SendNumber(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i ++)		
	{
		Voice_SendByte(Number / Voice_Pow(10, Length - i - 1) % 10 + '0');	
	}
}

/*
函    数：自己封装的prinf函数
参    数：format 格式化字符串
参    数：... 可变的参数列表
返 回 值：无
复制于江科大移植函数
*/
void Voice_Printf(char *format, ...)
{
	char String[100];				      //定义字符数组
	va_list arg;					      //定义可变参数列表数据类型的变量arg
	va_start(arg, format);			      //从format开始，接收参数列表到arg变量
	vsprintf(String, format, arg);	      //使用vsprintf打印格式化字符串和参数列表到字符数组中
	va_end(arg);					      //结束变量arg
	Voice_SendString(String);		      //串口发送字符数组（字符串）
}

/*
查询接收标志位
标志位读取后自动清零
*/
uint8_t Voice_GetRxFlag(void)
{
	if (Voice_RxFlag == 1)			      //如果标志位为1
	{                                     
		Voice_RxFlag = 0;                
		return 1;					      //则返回1，并自动清零标志位
	}                                     
	return 0;						      //如果标志位为0，则返回0
}

/*
蓝牙获取串口接收数据的函数
形参
*/
uint8_t Voice_GetRxData(void)
{
	return Voice_RxData;			     //返回接收的数据变量
}


void USART3_IRQHandler(void)
{                                                                
	if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)		 //判断是否是USART1的接收事件触发的中断
	{                                                            
		Voice_RxData = USART_ReceiveData(USART3);				 //读取数据寄存器，存放在接收的数据变量
		Voice_RxFlag = 1;										 //置接收标志位变量为1
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);			 //清除USART1的RXNE标志位
																 //读取数据寄存器会自动清除此标志位
																 //如果已经读取了数据寄存器，也可以不执行此代码
	}
}
