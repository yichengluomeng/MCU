#ifndef __MODE_H
#define __MODE_H

void MODE_Init();//初始化PWM底层
void MODE_Advance();//前进
void MODE_Retreat();//后退
void MODE_Right();//右转
void MODE_Left();//左转
void MODE_Attention();//立正
void MODE_Beckon();//招手
void MODE_Sway();//摇摆
void MODE_Ultrasound();//超声避障

#endif