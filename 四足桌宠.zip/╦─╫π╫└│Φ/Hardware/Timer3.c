#include "stm32f10x.h"                  // Device header

extern uint16_t Num;

void TIM3_Init()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	
	//启用内部时钟
	TIM_InternalClockConfig(TIM2);
	
	//初始化定时器
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;//
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1; //
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;//
	TIM_TimeBaseInitStructure.TIM_Period = 1000 - 1;//每1ms触发一次中断
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;//每1ms触发一次中断
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
	
	//清除更新中断标志位
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
	
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);//开启TIM3更新中断
	
	//中断优先级
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	//NVIC
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM3,DISABLE);//开启超声避障时打开
}

void TIM3_IRQHandler()
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)		//判断是否是TIM的更新事件触发的中断
	{
		Num++;												//由于超声波模块的计数													
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);			//清除TIM3的TIM_IT_Update标志位
															//读取数据寄存器会自动清除此标志位
															//如果已经读取了数据寄存器，也可以不执行此代码
	}
}