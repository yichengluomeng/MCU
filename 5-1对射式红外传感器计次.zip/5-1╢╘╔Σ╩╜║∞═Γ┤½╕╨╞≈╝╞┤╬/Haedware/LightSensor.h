#ifndef __LIGHTSENSOR_H
#define __LIGHTSENSOR_H

void LightSensor_Init();
uint8_t LightSensor_Get();

#endif