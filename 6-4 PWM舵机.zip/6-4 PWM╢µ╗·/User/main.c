#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "KEY.h"

uint16_t KeyNum;
float Angle=0;

int main(void)
{
	OLED_Init();
	servo_Init();
	Key_Init();
	while (1)
	{
		KeyNum=Key_GetNum();
		if (KeyNum == 1)
		{
			Angle += 30;
			if (Angle > 180)
			{
				Angle = 0;
			}
		}if (KeyNum == 2)
		{
			Angle -= 30;
			if (Angle < 0)
			{
				Angle = 180;
			}
		}
		servo_SetAngle(Angle);
	}
}
