#ifndef __SERVO_H
#define __SERVO_H

void servo_Init();
void servo_SetAngle(float Angle);

#endif
