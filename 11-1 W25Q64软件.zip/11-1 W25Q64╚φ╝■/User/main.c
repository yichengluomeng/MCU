#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "W25Q64.h"
int main(void)
{
	W25Q64_Init();
	OLED_Init();
	uint16_t DID;
	uint8_t MID;
	uint8_t Send_Array[]={0x11,0x22,0x33,0xa4};
	uint8_t Data_Array[4];
	W25Q64_ReadID(&MID,&DID);
	
	W25Q64_SectorErase(0x000000);
	
	W25Q64_PageProgram(0x000000,Send_Array,4);
	
	W25Q64_ReadData(0x000000,Data_Array,4);

	OLED_ShowHexNum(2,1,Send_Array[0],2);
	OLED_ShowHexNum(2,3,Send_Array[1],2);
	OLED_ShowHexNum(2,5,Send_Array[2],2);
	OLED_ShowHexNum(2,7,Send_Array[3],2);
	OLED_ShowHexNum(3,1,Data_Array[0],2);
	OLED_ShowHexNum(3,3,Data_Array[1],2);
	OLED_ShowHexNum(3,5,Data_Array[2],2);
	OLED_ShowHexNum(3,7,Data_Array[3],2);
	
	OLED_ShowHexNum(1,5,MID,2);
	OLED_ShowHexNum(1,12,DID,4);
	while (1)
	{

	}
}
