#ifndef __MYSPI_H
#define __MYSPI_H

void MySPI_Init();
void SPI_Stard();
void SPI_Stop();
uint8_t SPI_SwapByte(uint8_t ByteSend);

#endif