#include "stm32f10x.h"                  // Device header

void LightSensor_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//初始化时钟

	GPIO_InitTypeDef GPIO_InitStructure;//定义结构体
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//赋值结构体（共8种）-上拉输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;//13口（可以使用按位或的方式赋值多个PIN口）也可以使用ALL赋值全部口
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//输出速度
	GPIO_Init(GPIOB,&GPIO_InitStructure);//将指定的GPIO口初始化
	
}

uint8_t LightSensor_Get()
{
		return GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13);
}