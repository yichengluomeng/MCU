#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_Init(void);
uint16_t CountSensor_Get(void);
int16_t Encoder_Get(void);
void CountSensor_Init(void);


#endif