#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void servo_Init()
{
	PWM_HXInit();
}

void servo_SetAngle(float Angle)
{
	PWM_SetCompare2(Angle/180*2000+500);
}