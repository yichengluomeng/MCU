#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "sys.h"

float pitch,roll,yaw;

int main(void)
{
	OLED_Init();
	mpu_dmp_init();
	

	
	while (1)
	{
		mpu_dmp_get_data(&pitch,&roll,&yaw);
		OLED_ShowSignedNum(1,1,pitch, 5);
		OLED_ShowSignedNum(2,1,roll, 5);
		OLED_ShowSignedNum(3,1,yaw, 5);
	}
}
