#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MPU6050.h"
#include "MPU6050_Reg.h"

int main(void)
{
	int16_t Ax,Ay,Az,Gx,Gy,Gz;
	
	OLED_Init();
	MPU6050_Init();
	
//	MPU6050_SendData(MPU6050_PWR_MGMT_1,0x00);
//	
//	MPU6050_SendData(MPU6050_SMPLRT_DIV,0xAA);
//	
//	OLED_ShowHexNum(1,1,MPU6050_ReadData2(MPU6050_SMPLRT_DIV),4);
//	
	while (1)
	{
		MPU6050_GetValue(&Ax,&Ay,&Az,&Gx,&Gy,&Gz);
		OLED_ShowSignedNum(1,1,Ax,5);
		OLED_ShowSignedNum(2,1,Ay,5);
		OLED_ShowSignedNum(3,1,Az,5);
		OLED_ShowSignedNum(1,9,Gx,5);
		OLED_ShowSignedNum(2,9,Gy,5);
		OLED_ShowSignedNum(3,9,Gz,5);
	}
}
