#ifndef __MPU6050_H
#define __MPU6050_H

void MPU6050_Init();
void MPU6050_SendData(uint8_t RegAddRess, uint8_t Data);
uint8_t MPU6050_ReadData1(uint8_t RegAddRess);
uint8_t MPU6050_ReadData2(uint8_t RegAddRess);

//uint8_t MPU6050_ReadData2s(uint8_t RegAddRess,uint8_t lens);

void MPU6050_GetValue(int16_t *AccX, int16_t *AccY, int16_t *AccZ, 
					  int16_t *GyroX, int16_t *GyroY, int16_t *GyroZ);

#endif