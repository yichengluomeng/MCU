#ifndef __MYI2C_H
#define __MYI2C_H

void MyI2C_Init();
void MyI2C_Start();
void MyI2C_Stop();
void MyI2C_SendByte(uint8_t Byte);
uint8_t MyI2C_ReadByte();
void MyI2C_SendBit(uint8_t Bit);
uint8_t MyI2C_ReadBit();

#endif