#ifndef __SERVO_CHASSIS_H
#define __SERVO_CHASSIS_H

void PWM3_Init();
void TIM3OC2_GetValue(uint16_t CCR_Num);
void Servo3_SetAngle(float Angle);

#endif