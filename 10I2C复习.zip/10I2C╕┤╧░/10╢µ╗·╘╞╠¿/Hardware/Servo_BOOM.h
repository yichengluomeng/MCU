#ifndef __SERVO_BOOM_H
#define __SERVO_BOOM_H

void PWM2_Init();
void TIM2OC1_GetValue(uint16_t CCR_Num);
void Servo2_SetAngle(float Angle);

#endif