#include "stm32f10x.h"                  // Device header

void PWM2_Init()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//����ʱ��
	
	TIM_InternalClockConfig(TIM2);//�����ڲ�ʱ��Դ

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//
	
	GPIO_InitTypeDef GPIO_InitStructure;//��ʼ��GPIO
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;//��ʼ��ʱ����Ԫ
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;//
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;//
	TIM_TimeBaseInitStructure.TIM_Period =20000-1;//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72-1 ;//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;//
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);
	
	TIM_OCInitTypeDef TIM_OCInitStructure;//��ʼ������Ƚϵ�Ԫ
	TIM_OCStructInit(&TIM_OCInitStructure);//Ϊ����ȽϽṹ�ṹ�帳��ʼֵ
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1 ;//PWM1ģʽ
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;//�ߵ�ƽ�����Բ���ת
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;//CCRռ�ձ�
	TIM_OC1Init(TIM2, &TIM_OCInitStructure);//��ʼ������Ƚ�
	
	TIM_Cmd(TIM2,ENABLE);
}

void TIM2OC1_GetValue(uint16_t CCR_Num)//�����޸�CCRռ�ձ�
{
	TIM_SetCompare1(TIM2,CCR_Num);
}

/*
0�㡪��500
180�㡪��2500
ʵ�ʽǶ�=Angle/180*2000+500
*/
void Servo2_SetAngle(float Angle)
{
	TIM2OC1_GetValue(Angle/180*2000+500);
}
