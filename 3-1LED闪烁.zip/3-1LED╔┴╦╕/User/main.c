#include "stm32f10x.h"                  // Device header
#include "Delay.h"   
int main(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE); //配置时钟
	
	GPIO_InitTypeDef GPIO_InitStruscture;//配置GPIO
	GPIO_InitStruscture.GPIO_Mode = GPIO_Mode_Out_PP;//推挽输出
	GPIO_InitStruscture.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStruscture.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruscture);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_3);
//	GPIO_WriteBit(GPIOA,GPIO_Pin_0,Bit_SET);
	
	while (1)
	{
//		GPIO_WriteBit(GPIOA,GPIO_Pin_3,Bit_RESET);
//		Delay_ms(500);
//		GPIO_WriteBit(GPIOA,GPIO_Pin_3,Bit_SET);	
//		Delay_ms(500);	
//		GPIO_ResetBits(GPIOA,GPIO_Pin_1);	
//		Delay_ms(100);	
//		GPIO_SetBits(GPIOA,GPIO_Pin_1);
//		Delay_ms(100);		
	
	}
}   
