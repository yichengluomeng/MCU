#include "stm32f10x.h"                  // Device header

void PWM_Init()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruscture;//配置GPIO
	GPIO_InitStruscture.GPIO_Mode = GPIO_Mode_AF_PP;//推挽输出  各种输出再看一看比较重要
	GPIO_InitStruscture.GPIO_Pin = GPIO_Pin_2;// GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3;
	GPIO_InitStruscture.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruscture);
	
//	TIM_ETRClockMode2Config(TIM2,TIM_ExtTRGPSC_OFF,TIM_ExtTRGPolarity_NonInverted,0x00);
	TIM_InternalClockConfig(TIM2);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;//结构体
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1; //分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;//通道
	TIM_TimeBaseInitStructure.TIM_Period = 100 - 1;//ARR   与另外两个的关系和计算方式记得再看看
	TIM_TimeBaseInitStructure.TIM_Prescaler = 36 - 1;//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
	
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);//结构体赋默认值
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
	
//	TIM_OC1Init(TIM2, &TIM_OCInitStructure);
//	TIM_OC2Init(TIM2, &TIM_OCInitStructure);
	TIM_OC3Init(TIM2, &TIM_OCInitStructure);
//	TIM_OC4Init(TIM2, &TIM_OCInitStructure);
	TIM_Cmd(TIM2, ENABLE);
}

//void PWM_SetCompare1(uint16_t Compare)
//{
//	TIM_SetCompare1(TIM2,Compare);
//}

//void PWM_SetCompare2(uint16_t Compare)
//{
//	TIM_SetCompare2(TIM2,Compare);
//}

void PWM_SetCompare3(uint16_t Compare)
{
	TIM_SetCompare3(TIM2,Compare);
}

//void PWM_SetCompare4(uint16_t Compare)
//{
//	TIM_SetCompare4(TIM2,Compare);
//}