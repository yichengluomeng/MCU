#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Timer.h"
#include "Encoder.h"

int16_t seepd;

int main(void)
{
	OLED_Init();
	Timer_Init();
	Encoder_Init();
	OLED_ShowString(1, 1, "NUM:");	
	
	while (1)
	{
		OLED_ShowSignedNum(1,5,seepd,5);
		Delay_ms(1000);
	}
}

void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2,TIM_IT_Update) == SET)
	{
		seepd=Encoder_GET();
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	}
}