#include "stm32f10x.h"                  // Device header

void Timer_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//开启时钟外设
	
	TIM_InternalClockConfig(TIM2);//时钟配置
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;//结构体
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1; //分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;//通道
	TIM_TimeBaseInitStructure.TIM_Period = 10000 - 1;//
	TIM_TimeBaseInitStructure.TIM_Prescaler = 7200 - 1;//计数
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
	
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);//配置中断通道到NVIC
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//开启中断优先级
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM2, ENABLE);
}
/*
void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2,TIM_IT_Update) == SET)
	{
		
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	}
}
*/