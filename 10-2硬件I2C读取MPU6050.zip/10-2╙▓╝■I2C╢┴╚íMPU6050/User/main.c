#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MPU6050.h"

int16_t Ax,Ay,Az,Gx,Gy,Gz;
int main(void)
{
	OLED_Init();
	MPU6050_Init();

	while (1)
	{
		MPU6050_GetData(&Ax,&Ay,&Az,&Gx,&Gy,&Gz);
		OLED_ShowSignedNum(2, 1, Ax, 5);					//OLED显示数据
		OLED_ShowSignedNum(3, 1, Ay, 5);
		OLED_ShowSignedNum(4, 1, Az, 5);
		OLED_ShowSignedNum(2, 8, Gx, 5);
		OLED_ShowSignedNum(3, 8, Gy, 5);
		OLED_ShowSignedNum(4, 8, Gz, 5);
	}
}
