#include "stm32f10x.h"                  // Device header
#include "MySPI.h"
#include "W25Q64_Ins.h"
void W25Q64_Init()
{
	MySPI_Init();
}

void W25Q64_ReadID(uint8_t *MID,uint16_t *DID)
{
	SPI_Stard();
	SPI_SwapByte(W25Q64_JEDEC_ID);
	*MID=SPI_SwapByte(W25Q64_DUMMY_BYTE);
	*DID=SPI_SwapByte(W25Q64_DUMMY_BYTE);
	*DID<<=8;
	*DID|=SPI_SwapByte(W25Q64_DUMMY_BYTE);
	SPI_Stop();
}

void W25Q64_Write_Enable()
{
	SPI_Stard();
	SPI_SwapByte(W25Q64_WRITE_ENABLE);
	SPI_Stop();
}

void W25Q64_WaitBusy()
{
	uint32_t i;
	SPI_Stard();
	SPI_SwapByte(W25Q64_READ_STATUS_REGISTER_1);
	i=100000;
	while ((SPI_SwapByte(W25Q64_DUMMY_BYTE) & 0x01) == 0x01)
	{
		i--;
		if (i==0)
		{
			break;
		}
	}
	SPI_Stop();
}

void W25Q64_PageProgram(uint32_t Address ,uint8_t *DataArray ,uint16_t Count)
{
	uint16_t i;
	W25Q64_Write_Enable();
	SPI_Stard();
	SPI_SwapByte(W25Q64_PAGE_PROGRAM);
	SPI_SwapByte(Address>>16);
	SPI_SwapByte(Address>>8);
	SPI_SwapByte(Address);
	for (i=0;i<Count;i++)
	{
		SPI_SwapByte(DataArray[i]);
	}
	SPI_Stop();
	W25Q64_WaitBusy();
}

void W25Q64_SectorErase(uint32_t Address)
{
	W25Q64_Write_Enable();
	SPI_Stard();
	SPI_SwapByte(W25Q64_SECTOR_ERASE_4KB);
	SPI_SwapByte(Address>>16);
	SPI_SwapByte(Address>>8);
	SPI_SwapByte(Address);
	SPI_Stop();
	W25Q64_WaitBusy();
}

void  W25Q64_ReadData(uint32_t Address,uint8_t *DataArray ,uint16_t Count)
{
	uint16_t Data,i;
	SPI_Stard();
	SPI_SwapByte(W25Q64_READ_DATA);
	SPI_SwapByte(Address>>16);
	SPI_SwapByte(Address>>8);
	SPI_SwapByte(Address);
	for (i=0;i<Count;i++)
	{
		DataArray[i]=SPI_SwapByte(W25Q64_DUMMY_BYTE);
	}
	SPI_Stop();
}